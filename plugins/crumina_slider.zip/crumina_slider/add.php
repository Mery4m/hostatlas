<form action="<?php echo $_SERVER['REQUEST_URI'] ?>" method="post" class="wrap" id="ls-slider-form">

	<input type="hidden" name="posted_add" value="1">

	<h2>
		<?php _e('Add New Slider', 'crum') ?>
		<a href="?page=crumina_slider" class="add-new-h2"><?php _e('Back to the list', 'crum') ?></a>
	</h2>

	<div id="ls-pages">

		<div class="ls-page ls-settings active">

			<div id="post-body-content">
				<div id="titlediv">
					<div id="titlewrap">
						<input type="text" name="title" value="" id="title" autocomplete="off" placeholder="<?php _e('Slider name', 'crum') ?>">
					</div>
				</div>
			</div>

			<div class="ls-box ls-settings" id="hor-zebra">
				<table>
					<thead>
						<tr>
							<td colspan="3">

								<h4><?php _e('Slider settings', 'crum') ?></h4>
							</td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><?php _e('Choose Sorting of Posts/Pages', 'crum') ?></td>
							<td>
							<select name="slider[sort]">
							<option value='date'>Date</option>
							<option value='ID'>Post ID</option>
							<option value='name'>Slug</option>
							<option value='title'>Title</option>
							<option value='author'>Author ID</option>
							</select>
							<td class="desc"></td>
						</tr>
						<tr>
							<td><?php _e('Number of Posts/Pages', 'crum') ?></td>
							<td>
							<select name="slider[posts]">
							<option value="1">1</option>
							<option value="2">2</option>
							<option value="4">4</option>
							<option value='8'>8</option>
							<option value='12'>12</option>
							</select>
							</td>
							<td class="desc"></td>
						</tr>
						<tr>
							<td><?php _e('Slider items from Posts/Pages', 'crum') ?></td>
							<td>
							<?php

                            $all_post_types = (array('post','page','product','my-product'));

							echo '<select name="slider[post_type][]" multiple="multiple" style="width: 350px;height: 150px;">';
							
							foreach ($all_post_types as $post_type_name)
							{
								//echo $post_type_name;
								$args = array('post_status' => 'publish','post_type' => $post_type_name, 'numberposts' => '-1');
								$post_type_items = get_posts($args);

								if(is_array($post_type_items))
								{
									
									foreach($post_type_items as $post_type)
									{
										echo '<option value="' . $post_type->ID . '">' . ucfirst($post_type->post_type) . ' - ' . $post_type->post_title . '</option>';
									}
									
								}

							}
							echo '</select>';
                        ?>
							
							
                        	</td>
							<td class="desc"></td>
						</tr>
                        <tr>
							<td><?php _e('Choose Order of Posts/Pages', 'crum') ?></td>
							<td>
							<select name="slider[sort_order]">
							<option value='asc'>ASC</option>
							<option value='desc'>DESC</option>
							</select>
							
							</td>
							<td class="desc"></td>
						</tr>
                        <tr>
							<td><?php _e('Limit Description (Number of chars)', 'crum') ?></td>
							<td><input type="text" name="slider[chars_limit]" value="300" class="input"></td>
							<td class="desc"></td>
						</tr>
                        <tr>
							<td><?php _e('More Seperator', 'crum') ?></td>
							<td><input type="text" name="slider[separator]" value="..." class="input"></td>
							<td class="desc"></td>
						</tr>
                        <tr>
							<td><?php _e('Set Slider Effect', 'crum') ?></td>
							<td>
                                <select name="slider[effect]" style="width: 200px;">
                                <option value="horizontal-push">Horizontal Push</option>
                                <option value="fade">Fade</option>
                                <option value="horizontal-slide">Horizontal</option>
                                </select>
							</td>
							<td class="desc"></td>
						</tr>
                        <tr>
                            <td><?php _e('Set Slider Timeout (in ms)', 'crum') ?></td>
                            <td><input type="text" name="slider[timeout]" value="500" class="input"></td>
                            <td class="desc"></td>
                        </tr>
                        <tr>
							<td><?php _e('Enable Auto Slider', 'crum') ?></td>
							<td><input type="checkbox" name="slider[auto_mode]"></td>
							<td class="desc"></td>
						</tr>
                        <tr>
							<td><?php _e('Auto Slider Speed (ms)', 'crum') ?></td>
							<td><input type="text" name="slider[auto_mode_speed]" class="input" value="2000"></td>
							<td class="desc"></td>
						</tr>
                        <tr>
							<td><?php _e('Set Background Color', 'crum') ?></td>
							<td><input type="text" id="background_color" name="slider[backgr_color]" value="#50b4e6" class="input">
							<div id="color_picker_background_color"></div>
							</td>
							<td class="desc"></td>
						</tr>
						
                        <tr>
							<td><?php _e('Set Opacity (0 - 100)', 'crum') ?></td>
							<td><input type="text" name="slider[opacity]" value="82" class="input">
							
							</td>
							<td class="desc"></td>
						</tr>

                        <tr>
							<td><?php _e('Set Button Color', 'crum') ?></td>
							<td><input type="text" id="button_color" name="slider[button_color]" value="#e7e7e7" class="input">
							<div id="color_picker_button"></div>
							</td>
							<td class="desc"></td>
						</tr>

                        <tr>
							<td><?php _e('Set Active Button Color', 'crum') ?></td>
							<td><input type="text" id="active_button" name="slider[button_color_active]" value="#51585b" class="input">
							<div id="color_picker_active_button"></div>
							</td>
							<td class="desc"></td>
						</tr>

						<tr>
							<td><?php _e('Show date', 'crum') ?></td>
							<td><input type="checkbox" checked="checked" name="slider[show_date]"></td>
							<td class="desc"></td>
						</tr>

					</tbody>


				</table>
			</div>
		</div>

	</div>

		<div class="inner">
			<button class="button-primary"><?php _e('Save changes', 'crum') ?></button>
			<p class="ls-saving-warning"></p>
			<div class="clear"></div>
		</div>

</form>