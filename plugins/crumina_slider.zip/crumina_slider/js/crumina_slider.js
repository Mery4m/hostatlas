jQuery(document).ready(function($) {

	$('#button_color').wpColorPicker();
	$('#active_button').wpColorPicker();
	$('#background_color').wpColorPicker();



});