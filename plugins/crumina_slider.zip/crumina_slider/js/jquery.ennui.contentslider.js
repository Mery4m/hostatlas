(function ($) {
	$.fn.ContentSlider = function (options) {

		var defaults = {
			width:'5000px',
			height:'400px',
			speed:100
		}
		
		      

		
		var defaultWidth = defaults.width;
		var o = jQuery.extend(defaults, options);
		var w = parseInt(o.width);
		var n = this.children('.slider-wrap').children('.block').length;
		var x = -1 * w * n + w;
		var p = parseInt(o.width) / parseInt(defaultWidth);
		var thisInstance = this.attr('id');
		var inuse = false;

		function moveSlider_my(d, page)
		{
			var l = parseInt($('.cs_slider').css('left'));

			if (isNaN(l)) {
				var l = 0;
			}

			w = $('.slider-wrap').outerWidth(true);
			
			if(page ==0)
			{
				var m = 0;
			}
			else
			{
				var m = (w * page)*(-1);
			}

			if (m <= 0) {
				$('.clearing-container.slider').animate({ 'left': m + 'px' }, o.speed, '', function () {
					inuse = false;
				});
			}
		}

		function show_buttons(n) {
			var num = n;
			var pag = [];
			for (var i = 1; i <= num; i++) {
				pag.push(i);
			}

			$(pag).each(function (index, value) {
				$("#slider_pagination").append('<a id="slider_tabs" href="#" page="'+ index +'"></a> ');
			});
		}

		show_buttons(n);

		$("a#slider_tabs").bind('click', function () {
			
			/*$("div.slider-wrap").each(function() {
				//alert('ddd');
  $(this).hide("clip", { direction: "vertical" }, 5000);		
});*/

				/*$(".slider-wrap#1").fadeOut(2000);	
				$(".slider-wrap#5").fadeIn(2000);*/
				/*
				$('.slider-wrap#1').fadeOut(2500, function() {
        var $this = $(this);
        //$this.text($this.text() == 'Connected' ? '2457' : 'Connected');        
        //$this.toggleClass('first second');        
        $('.slider-wrap#5').fadeIn(2500);
    });	*/
			
			slider_page = $(this).attr("page");
			$("a#slider_tabs").removeClass();
			$(this).attr("class", "active");
			moveSlider_my('right', slider_page);
			return false; 
		});
	}
})(jQuery)