<?php

include_once('inc/functions.php');

function my_theme_options($menu_settings)
{
    ?>
<div class="wrap">
    <div id="icon-themes" class="icon32"><br></div>

    <?php echo "<h2>" . __('Crumina Menu customizer', 'crum') . "</h2>"; ?>

    <form method="POST" id="menu_js_settings" action="">
        <input type="hidden" name="func" value="save_js_settings">

        <div style="width: 100%">

            <div style="width: 120px;float:left;">
                <p><?php echo __('Animation Effect:', 'crum'); ?><br>
                    <select name="menu_user_animation">
                        <option value="fade_in" <?php if ($menu_settings['user_animation'] == 'fade_in') echo 'selected="selected"'; ?>>
                            Fade In
                        </option>
                        <option value="slide_down" <?php if ($menu_settings['user_animation'] == 'slide_down') echo 'selected="selected"'; ?>>
                            Slide Down
                        </option>
                    </select>
                </p>
            </div>

            <div style="width: 100px;float:left;">
                <p><?php echo __('Animation Speed:', 'crum'); ?><br>
                    <select name="menu_user_speed">
                        <option value="fast" <?php if ($menu_settings['user_speed'] == 'fast') echo 'selected="selected"'; ?>>
                            Fast
                        </option>
                        <option value="normal" <?php if ($menu_settings['user_speed'] == 'normal') echo 'selected="selected"'; ?>>
                            Normal
                        </option>
                        <option value="slow" <?php if ($menu_settings['user_speed'] == 'slow') echo 'selected="selected"'; ?>>
                            Slow
                        </option>
                    </select>
            </div>

            <div style="width: 180px;float:left; padding-top: 25px;">
                <p><input type="checkbox" name="menu_active_icon_hover" <?php if (isset($menu_settings['menu_active_icon_hover']) && !empty($menu_settings['menu_active_icon_hover']) ) echo 'checked'; ?> > <?php echo __('Show Active Icon On Hover', 'crum'); ?>
            </div>

            <div style="width: 50px;float:left;padding-top: 16px;">
                <p><input type="submit" id="save_js_settings" class="button-primary" name="update_options"
                          value="<?php echo __('Save Animation Options', 'crum'); ?>"/>
                </p>
            </div>
        </div>

    </form>

    <?php
}

function get_main_menu_selectbox($slug_menu)
{
    echo __('Select menu:', 'crum') . '<br>';
    echo '<select id="menu-list" name="menu_slug_name">';

    $menus = get_terms('nav_menu');

    foreach ($menus as $menu) {
        if ($menu->slug == $slug_menu) $selected = ' selected = "selected" '; else $selected = '';
        echo '<option value="' . $menu->slug . '" ' . $selected . '  >' . $menu->name . '</option>';

    }
    echo '</select>';
}

function get_mega_menu_items($name, $mega_menu_item, $checked, $mega_menu_width)
{
    static $crumina_mega_menu_items;

    if (empty($crumina_mega_menu_items)) {
        $args = array('post_type' => 'crumina_mega_menu');
        $crumina_mega_menu_items = get_posts($args);
    } else {
        $crumina_mega_menu_items;
    }

    if (count($crumina_mega_menu_items) > 0) {
        echo '<input type="checkbox" name="' . $name . '[mega_menu_active]" ' . $checked . '>
              <label for="upload_image">' . __('Use Mega Menu?', 'crum') . '</label><br>';

        echo '<label>' . __('Select Mega Menu Item', 'crum') . '</label><br>';
        echo '<select name="' . $name . '[mega_menu_item]" style="width:100%;" >';
        foreach ($crumina_mega_menu_items as $menu_item) {
            if ($menu_item->ID == $mega_menu_item) $selected = ' selected = "selected" '; else $selected = '';
            echo "<option value='$menu_item->ID' $selected >" . $menu_item->post_title . "</option>";
        }
        echo '</select>';

        echo '<label for="upload_image">' . __('Mega Menu Width', 'crum') . '</label>
              <input size="36" name="' . $name . '[mega_menu_width]" type="text" value = "' . $mega_menu_width . '" />
              <br>';
    } else {
        echo '<b>' . __('If you want use MegaMenu, first you need create mega menu items', 'crum') . '</b><br>';
    }

}

function show_crum_menus_items_list($slug_menu)
{
    if (empty($slug_menu)) $slug_menu = 'primary-navigation';

    $menu_items = wp_get_nav_menu_items($slug_menu);
    $menu_settings = get_menu_settings();

    echo '<br><br><div>';

    echo "<form method='POST' action=''>";
    echo "<input type='hidden' name='func' value='save_menu_settings'>";

    ?>

    <div style="width: 150px;">
        <br><br><br>
        <?php
        get_main_menu_selectbox($slug_menu);
        ?>
    </div>

    <?php

    foreach ($menu_items as $menu_item) {
        if ($menu_item->menu_item_parent == 0) {

//            $menu_title = str_replace(" ", "-", strtolower($menu_item->title));
            $menu_title = $menu_item->ID;

            if (is_array($menu_settings)) {
                $menu_icon = (isset($menu_settings[$slug_menu][$menu_title]['active_icon'])) ? $menu_settings[$slug_menu][$menu_title]['active_icon'] : '';
                $menu_hover_icon = (isset($menu_settings[$slug_menu][$menu_title]['hover_icon'])) ? $menu_settings[$slug_menu][$menu_title]['hover_icon'] : '';
                $mega_menu_width = (isset($menu_settings[$slug_menu][$menu_title]['mega_menu_width'])) ? $menu_settings[$slug_menu][$menu_title]['mega_menu_width'] : '';
                $mega_menu_item = (isset($menu_settings[$slug_menu][$menu_title]['mega_menu_item'])) ? $menu_settings[$slug_menu][$menu_title]['mega_menu_item'] : '';
                $mega_menu_active = (isset($menu_settings[$slug_menu][$menu_title]['mega_menu_active'])) ? $menu_settings[$slug_menu][$menu_title]['mega_menu_active'] : '';
            }

            echo '<div style="margin:0px;padding:20px;width:230px;float:left;background-color: #ffffff;">';

            ?>


            <div style="float: left;width: 100%">

                <nav id="top-menu" class="fake">
                    <ul id="menu-main-menu" class="menu">
                        <li class="current-menu-item has-submenu" id="main-menu-help"
                            style="background-color: #FFFFFF;">
                <span class="menu-item-wrap">
                    <a href="http://dev.crumina.net/maestro/" style="">
                        <span class="tile-icon">
                            <img id="ac_ic_menu_data<?php echo $menu_item->post_type . $menu_title ?>active_icon"
                                 src="<?php echo $menu_icon; ?>" class="active-icon"
                                 style="display: inline;width: 32px;height: 32px;border:0px;">
                            <img id="hv_ic_menu_data<?php echo $menu_item->post_type . $menu_title ?>hover_icon"
                                 src="<?php echo $menu_hover_icon; ?>" class="normal-icon"
                                 style="display: none;width: 32px;height: 32px;border:0px;">
                        </span>
                        <span class="link-text"><?php echo $menu_item->title; ?> </span>
                    </a>
                </span>

                            <div class="under"></div>
                        </li>

                    </ul>
                </nav>
            </div>
        <?php


            echo '
            <label for="upload_image">Menu Icon </label>
            <input id="menu_data' . $menu_item->post_type . $menu_title . 'active_icon" name="menu_data[' . $slug_menu . '][' . $menu_title . '][active_icon]" size="36"
            class="metro-item-icon icon-item-' . $menu_item->ID . '" data-item="menu_data[' . $menu_item->post_type . '][' . $menu_title . '][active_icon]" type="text"
              value = "' . $menu_icon . '"/>
            <input class="button-secondary remove-icon" id="menu_data' . $menu_item->post_type . $menu_title . 'active_icon"  value="Remove Icon" type="button" /> </label>
            <br>';

            echo '
            <label for="upload_image"> Menu Hover Icon
            <input id="menu_data' . $menu_item->post_type . $menu_title . 'hover_icon" size="36" name="menu_data[' . $slug_menu . '][' . $menu_title . '][hover_icon]"
            class="metro-item-icon icon-item-' . $menu_item->ID . '" data-item="' . $menu_item->ID . '" type="text"
            value = "' . $menu_hover_icon . '" />


            <input class="button-secondary remove-icon" id="menu_data' . $menu_item->post_type . $menu_title . 'hover_icon"  value="Remove Icon" type="button" /> </label>
            <br><br>';

            if ($mega_menu_active == 'on') {
                $checked = 'checked';
            } else {
                $checked = '';
            }

            echo get_mega_menu_items('menu_data[' . $slug_menu . '][' . $menu_title . ']', $mega_menu_item, $checked, $mega_menu_width);

            echo '</div>';

        }
    }

    echo '</div>';

    echo '<div class="clear"></div> ';
    echo '<br><input class="button-primary" style="float:none;" type="submit" id="save_menu" value="Save">';
    echo "</form>";
}


$menu_slug_name = get_menu_slug();

construct();

my_theme_options(get_js_settings());
show_crum_menus_items_list($menu_slug_name);