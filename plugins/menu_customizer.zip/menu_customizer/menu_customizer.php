<?php

/*
Plugin Name: Crumina Menu Customizer
Description: Plugin for creating different menu with any icons or background color
Author: afstanislav
Version: 1.0
*/

if (!defined('ABSPATH')) die('');

function crumina_menu_admin_actions()
{
    add_theme_page("Crumina Menu Customizer", "Menu Customizer", 'manage_options', "crumina_customizer.php", "crumina_menu_admin");
}

function crumina_menu_admin()
{
    include("crumina_customizer.php");
}

add_action('admin_menu', 'crumina_menu_admin_actions');

function crumina_get_js_code($saved_options)
{
    ?>

<script type="text/javascript">

    jQuery(document).ready(function () {

        var menu_speed = '<?php echo (!empty($saved_options["user_speed"])) ? $saved_options["user_speed"] : 'normal'; ?>';
        var animation_effect = '<?php echo (!empty($saved_options["user_animation"])) ? $saved_options["user_animation"] : 'slide_down'; ?>';

		jQuery("nav#top-menu > ul > li > ul").hide();

        var windowWidth = jQuery(window).width();

        jQuery(window).resize(function() {
            //jQuery("nav#top-menu > ul > li > ul").hide();
            windowWidth = jQuery(window).width();
            //alert(windowWidth);
        }).resize();

                jQuery("nav#top-menu > ul > li").hover(function () {

                    if (animation_effect == 'fade_in')
                        jQuery('ul', this).stop(true, true).fadeIn(menu_speed);

                    if (animation_effect == 'slide_down')
                        jQuery('ul', this).stop(true, true).slideDown(menu_speed);


                }, function () {

                    if (animation_effect == 'fade_in')
                        jQuery('ul', this).stop(true, true).fadeOut(menu_speed);

                    if (animation_effect == 'slide_down')
                        jQuery('ul', this).stop(true, true).slideUp(menu_speed);

                });


        jQuery('nav#top-menu > ul > li').mouseleave(function() {
            jQuery("nav#top-menu > ul > li > ul").hide();
        });
        <?php
        $is_hover = (isset($saved_options['menu_active_icon_hover']) && !empty($saved_options['menu_active_icon_hover']));

        if($is_hover)
        {
        ?>
        jQuery(".menu-item-wrap").hover(function () {
            if(jQuery(this).parent("li").hasClass("current-menu-item"))
                jQuery(this).parent("li").addClass("was_active");
            else
                jQuery(this).parent("li").addClass("current-menu-item");

            jQuery("img.active-icon", this).css("display", "inline");
            jQuery("img.normal-icon", this).css("display", "none");

        }, function () {
            if(!jQuery(this).parent("li").hasClass("was_active"))
                jQuery(this).parent("li").removeClass("current-menu-item");
            jQuery("img.active-icon", this).css("display", "none");
            jQuery("img.normal-icon", this).css("display", "inline");
        });

        <?php
        }
        ?>

    });


</script>

<?php
}

function get_hover_styles($saved_menu_data)
{
    $css_content = '';

    if (is_array($saved_menu_data)) {
        $menu_item = key($saved_menu_data);

            foreach ($saved_menu_data[$menu_item] as $menu_title => $menu_data)
            {

                $css_content .= 'li#' . $menu_item . '-' . $menu_title . ' > ul li:hover, li#' . $menu_item . '-' . $menu_title . ' > ul li';
                $css_content .= '{';

                if (!empty($menu_data['mega_menu_active']))
                    $css_content .= 'margin: 0px !important; ';

                $css_content .= '}';

                $css_content .= 'li#' . $menu_item . '-' . $menu_title . ' > ul li:hover .menu-item-wrap a, li#' . $menu_item . '-' . $menu_title . ' > ul li .menu-item-wrap a';
                $css_content .= '{';

                if (!empty($menu_data['mega_menu_active']))
                    $css_content .= 'padding-left: 0px !important; background:none !important;';

                $css_content .= '}';
            }

            $theme_root    = get_template_directory() . '/css/';
            $menu_css_file = 'crumina_menu.css';

            if(!file_put_contents($theme_root . $menu_css_file, $css_content))
            {
                echo 'Chnage permissions to crumina_menu.css file';
            }
            else
            {
                wp_enqueue_style('my_crumina_mega_menu_css', get_template_directory_uri() . '/css/' . $menu_css_file);
            }
    }
}

function styles()
{
    $saved_options   = get_option('crumina_menu');
    $saved_menu_data = get_option('crumina_menu_data');

    crumina_get_js_code($saved_options);
    get_hover_styles($saved_menu_data);
}

add_action('wp_head', 'styles', 10);

function load_theme_scripts()
{
    wp_enqueue_script('thickbox');
    wp_enqueue_style('thickbox');

    wp_enqueue_script('my_crumina_menu', plugins_url('js/crumina_menu.js', __FILE__));
    wp_enqueue_style('my_crumina_menu_css', plugins_url('css/crumina_menu.css', __FILE__));
}

add_action('admin_enqueue_scripts', 'load_theme_scripts');